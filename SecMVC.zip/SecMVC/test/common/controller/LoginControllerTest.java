//http://java.dzone.com/articles/junit-testing-spring-mvc-1
	
package common.controller;

import static org.junit.Assert.*;

import org.junit.Test;

public class LoginControllerTest {

	@Test
	public void test()  throws Exception {
		fail("Not yet implemented");
		
//		MockMvc mockMvc = MockMvcBuilders.standaloneSetup(this.loginController).build();
//		mockMvc.perform(post("/login").param("username", "john").param("password", "secret"))
//				.andExpect(status().isOk())
//				.andExpect(request().sessionAttribute(LoginController.ACCOUNT_ATTRIBUTE, this.account))
//				.andExpect(redirectedUrl("/index.htm"));
	}

}
